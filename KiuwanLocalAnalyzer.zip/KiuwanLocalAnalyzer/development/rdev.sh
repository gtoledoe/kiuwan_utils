#! /bin/sh
SCRIPT=$(readlink -f "$0")
CURRDIR=$(dirname "$SCRIPT")
"$CURRDIR/../bin/agent.sh" --development
